package com.youkeda.app.service.impl;

import com.youkeda.app.dao.VotesDAO;
import com.youkeda.app.dataobject.VotesDO;
import com.youkeda.app.model.Result;
import com.youkeda.app.service.TicketPurchaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TicketPurchaseServiceImpl implements TicketPurchaseService {
    @Autowired
    private VotesDAO votesDAO;

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public Result<Boolean> ticketPurchase(long id) {
        //初始化返回数据
        Result result = new Result();
        result.data(true);
        result.setSuccess(true);
        //实现购买代码
        
        










        return result;
    }

}
