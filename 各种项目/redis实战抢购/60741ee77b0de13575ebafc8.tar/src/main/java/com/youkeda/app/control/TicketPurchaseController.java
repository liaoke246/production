package com.youkeda.app.control;

import com.youkeda.app.model.Result;
import com.youkeda.app.service.TicketPurchaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TicketPurchaseController {
    @Autowired
    private TicketPurchaseService ticketPurchaseService;

    /**
     * 抢票
     *
     * @return Result
     */
    @GetMapping("/ticketpurchase")
    @ResponseBody
    public Result<Boolean> ticketPurchase(Long id) {


        Result result = new Result();
        result.setSuccess(true);
        return result;
    }
}
