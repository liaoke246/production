package fm.douban.service;

import fm.douban.model.Subject;

public interface SubjectService {

    Subject get(String subjectId);

}