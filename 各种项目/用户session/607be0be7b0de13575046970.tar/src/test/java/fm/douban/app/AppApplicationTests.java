package fm.douban.app;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import fm.douban.model.UserLoginInfo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class YkdTest {

    static String sessionId;
    @LocalServerPort
    int randomServerPort;
    @Autowired
    private ObjectMapper mapper;

    public static void error(String msg) {
        System.err.println("<YkdError>" + msg + "</YkdError>");
    }

    @Test
    void contextLoads() throws Exception {

        post("app/authenticate?name=ZhangSan&password=123456", new TypeReference<Map>() {
        });

        UserLoginInfo result = get("app/info", new TypeReference<UserLoginInfo>() {
        });

        if (result == null || result.getUserName() == null) {
            error("没有正确的处理 userId 哦");
        }
    }

    private <T> T post(String url, TypeReference typeReference) throws Exception {
        String baseUrl = "http://localhost:" + randomServerPort + "/" + url;

        URI uri = new URI(baseUrl);
        HttpRequest.Builder builder = HttpRequest.newBuilder(uri).header("Content-Type", "application/json").POST(
            HttpRequest.BodyPublishers.noBody());

        if (sessionId != null) {
            builder.header("Cookie", sessionId);
        }

        HttpRequest request = builder.build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        String s = response.headers().firstValue("set-cookie").orElse(null);
        if (s != null) {
            sessionId = s;
        }

        return (T)mapper.readValue(response.body(), typeReference);
    }

    private <T> T get(String url, TypeReference typeReference) throws Exception {
        String baseUrl = "http://localhost:" + randomServerPort + "/" + url;

        URI uri = new URI(baseUrl);
        HttpRequest.Builder builder = HttpRequest.newBuilder(uri).header("Content-Type", "application/json").GET();

        if (sessionId != null) {
            builder.header("Cookie", sessionId);
        }

        HttpRequest request = builder.build();

        HttpClient client = HttpClient.newHttpClient();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        String s = response.headers().firstValue("set-cookie").orElse(null);
        if (s != null) {
            sessionId = s;
        }

        return (T)mapper.readValue(response.body(), typeReference);
    }

}
