package com.youkeda.app.service;

import com.youkeda.app.dataobject.CommentDO;

/**
 * @date 2020/6/16, 周二
 */
public interface CommentService {

    Integer add(CommentDO commentDO);

}
