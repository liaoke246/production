package com.youkeda.comment.api;

import com.youkeda.comment.model.Comment;
import com.youkeda.comment.service.CommentService;

import com.youkeda.comment.model.Result;
import com.youkeda.comment.model.User;
import com.youkeda.comment.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@Controller
public class CommentAPI {
   
@Autowired
private CommentService commentService;
 
    
    
   @PostMapping("/api/comment/post")
  public Result<Comment> post(HttpServletRequest request,HttpServletResponse response,@RequestParam("refId") String refId,@RequestParam("parentId") long parentId,@RequestParam("content") String content){
    HttpSession session = request.getSession();
    
    long userId = (long)session.getAttribute("userId");
    
    
    return commentService.post(refId,userId,parentId,content);
    
    
    
  }
    
    
    
    
}