package com.youkeda.comment.service;

import com.youkeda.comment.model.Comment;
import com.youkeda.comment.model.Result;

public interface CommentService {

    /**
     * 发布评论
     *
     * @param refId    外部 ID
     * @param userId   用户 ID
     * @param parentId 父评论 ID
     * @param content  评论内容
     * @return
     */
    public Result<Comment> post(String refId, long userId, long parentId, String content);

}
